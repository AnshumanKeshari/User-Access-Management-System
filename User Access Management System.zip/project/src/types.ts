export interface User {
  id: number;
  username: string;
  password: string;
  role: string;
}

export interface Software {
  id: number;
  name: string;
  description: string;
  accessLevels: string[];
}

export interface AccessRequest {
  id: number;
  userId: number;
  softwareId: number;
  accessType: string;
  reason: string;
  status: string;
  username?: string; // For display purposes
  softwareName?: string; // For display purposes
}