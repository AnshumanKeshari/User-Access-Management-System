import React, { createContext, useState, useContext, useEffect } from 'react';
import { User } from '../types';

interface UserContextType {
  currentUser: User | null;
  login: (username: string, password: string) => boolean;
  logout: () => void;
  signup: (username: string, password: string, role: string) => boolean;
  isAuthenticated: boolean;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export const useUser = () => {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
};

interface UserProviderProps {
  children: React.ReactNode;
}

// Mock users for demo
const mockUsers: User[] = [
  { id: 1, username: 'admin', password: 'admin123', role: 'Admin' },
  { id: 2, username: 'manager', password: 'manager123', role: 'Manager' },
  { id: 3, username: 'employee', password: 'employee123', role: 'Employee' },
];

export const UserProvider: React.FC<UserProviderProps> = ({ children }) => {
  const [users, setUsers] = useState<User[]>(() => {
    const storedUsers = localStorage.getItem('users');
    return storedUsers ? JSON.parse(storedUsers) : mockUsers;
  });
  
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const storedUser = localStorage.getItem('currentUser');
    return storedUser ? JSON.parse(storedUser) : null;
  });

  const isAuthenticated = currentUser !== null;

  useEffect(() => {
    localStorage.setItem('users', JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem('currentUser', currentUser ? JSON.stringify(currentUser) : '');
  }, [currentUser]);

  const login = (username: string, password: string) => {
    const user = users.find(
      (u) => u.username === username && u.password === password
    );
    
    if (user) {
      setCurrentUser(user);
      return true;
    }
    
    return false;
  };

  const logout = () => {
    setCurrentUser(null);
  };

  const signup = (username: string, password: string, role: string) => {
    // Check if username already exists
    if (users.some((user) => user.username === username)) {
      return false;
    }

    const newUser: User = {
      id: users.length + 1,
      username,
      password,
      role,
    };

    setUsers([...users, newUser]);
    return true;
  };

  return (
    <UserContext.Provider value={{ currentUser, login, logout, signup, isAuthenticated }}>
      {children}
    </UserContext.Provider>
  );
};