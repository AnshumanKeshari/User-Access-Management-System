import React, { createContext, useState, useContext, useEffect } from 'react';
import { AccessRequest } from '../types';

interface RequestContextType {
  requests: AccessRequest[];
  addRequest: (userId: number, softwareId: number, accessType: string, reason: string) => void;
  updateRequestStatus: (id: number, status: 'Approved' | 'Rejected') => void;
  getPendingRequests: () => AccessRequest[];
  getUserRequests: (userId: number) => AccessRequest[];
}

const RequestContext = createContext<RequestContextType | undefined>(undefined);

export const useRequest = () => {
  const context = useContext(RequestContext);
  if (context === undefined) {
    throw new Error('useRequest must be used within a RequestProvider');
  }
  return context;
};

// Mock requests for demo
const mockRequests: AccessRequest[] = [
  { 
    id: 1, 
    userId: 3, 
    softwareId: 1, 
    accessType: 'Read', 
    reason: 'Need to view financial reports', 
    status: 'Pending',
    username: 'employee',
    softwareName: 'Accounting System'
  },
  { 
    id: 2, 
    userId: 3, 
    softwareId: 2, 
    accessType: 'Write', 
    reason: 'Need to update employee records', 
    status: 'Approved',
    username: 'employee',
    softwareName: 'HR Portal'
  },
];

interface RequestProviderProps {
  children: React.ReactNode;
}

export const RequestProvider: React.FC<RequestProviderProps> = ({ children }) => {
  const [requests, setRequests] = useState<AccessRequest[]>(() => {
    const storedRequests = localStorage.getItem('requests');
    return storedRequests ? JSON.parse(storedRequests) : mockRequests;
  });

  useEffect(() => {
    localStorage.setItem('requests', JSON.stringify(requests));
  }, [requests]);

  const addRequest = (userId: number, softwareId: number, accessType: string, reason: string) => {
    // Get username and software name for display purposes
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const software = JSON.parse(localStorage.getItem('software') || '[]');
    
    const user = users.find((u: any) => u.id === userId);
    const sw = software.find((s: any) => s.id === softwareId);
    
    const newRequest: AccessRequest = {
      id: requests.length + 1,
      userId,
      softwareId,
      accessType,
      reason,
      status: 'Pending',
      username: user?.username || 'Unknown',
      softwareName: sw?.name || 'Unknown Software'
    };
    
    setRequests([...requests, newRequest]);
  };

  const updateRequestStatus = (id: number, status: 'Approved' | 'Rejected') => {
    setRequests(
      requests.map((request) =>
        request.id === id ? { ...request, status } : request
      )
    );
  };

  const getPendingRequests = () => {
    return requests.filter((request) => request.status === 'Pending');
  };

  const getUserRequests = (userId: number) => {
    return requests.filter((request) => request.userId === userId);
  };

  return (
    <RequestContext.Provider 
      value={{ 
        requests, 
        addRequest, 
        updateRequestStatus, 
        getPendingRequests, 
        getUserRequests 
      }}
    >
      {children}
    </RequestContext.Provider>
  );
};