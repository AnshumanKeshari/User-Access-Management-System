import React, { createContext, useState, useContext, useEffect } from 'react';
import { Software } from '../types';

interface SoftwareContextType {
  software: Software[];
  addSoftware: (name: string, description: string, accessLevels: string[]) => void;
  getSoftwareById: (id: number) => Software | undefined;
}

const SoftwareContext = createContext<SoftwareContextType | undefined>(undefined);

export const useSoftware = () => {
  const context = useContext(SoftwareContext);
  if (context === undefined) {
    throw new Error('useSoftware must be used within a SoftwareProvider');
  }
  return context;
};

// Mock software for demo
const mockSoftware: Software[] = [
  { 
    id: 1, 
    name: 'Accounting System', 
    description: 'Financial management system for company accounts', 
    accessLevels: ['Read', 'Write', 'Admin'] 
  },
  { 
    id: 2, 
    name: 'HR Portal', 
    description: 'Human resources management system', 
    accessLevels: ['Read', 'Write', 'Admin'] 
  },
  { 
    id: 3, 
    name: 'Project Management Tool', 
    description: 'Task and project tracking system', 
    accessLevels: ['Read', 'Write', 'Admin'] 
  },
];

interface SoftwareProviderProps {
  children: React.ReactNode;
}

export const SoftwareProvider: React.FC<SoftwareProviderProps> = ({ children }) => {
  const [software, setSoftware] = useState<Software[]>(() => {
    const storedSoftware = localStorage.getItem('software');
    return storedSoftware ? JSON.parse(storedSoftware) : mockSoftware;
  });

  useEffect(() => {
    localStorage.setItem('software', JSON.stringify(software));
  }, [software]);

  const addSoftware = (name: string, description: string, accessLevels: string[]) => {
    const newSoftware: Software = {
      id: software.length + 1,
      name,
      description,
      accessLevels,
    };
    setSoftware([...software, newSoftware]);
  };

  const getSoftwareById = (id: number) => {
    return software.find(s => s.id === id);
  };

  return (
    <SoftwareContext.Provider value={{ software, addSoftware, getSoftwareById }}>
      {children}
    </SoftwareContext.Provider>
  );
};