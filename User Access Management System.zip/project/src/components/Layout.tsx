import React from 'react';
import { Outlet, Navigate } from 'react-router-dom';
import { useUser } from '../contexts/UserContext';
import Navbar from './Navbar';

const Layout: React.FC = () => {
  const { isAuthenticated, currentUser } = useUser();

  if (!isAuthenticated) {
    return <Navigate to="/login" />;
  }

  // Redirect to the appropriate dashboard based on role
  if (currentUser?.role === 'Employee' && window.location.pathname === '/') {
    return <Navigate to="/employee" />;
  } else if (currentUser?.role === 'Manager' && window.location.pathname === '/') {
    return <Navigate to="/manager" />;
  } else if (currentUser?.role === 'Admin' && window.location.pathname === '/') {
    return <Navigate to="/admin" />;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <main className="container mx-auto px-4 py-8">
        <Outlet />
      </main>
    </div>
  );
};

export default Layout;