import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useUser } from '../contexts/UserContext';
import { Shield, User, LogOut } from 'lucide-react';

const Navbar: React.FC = () => {
  const { currentUser, logout } = useUser();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <nav className="bg-blue-600 text-white shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center space-x-2">
            <Shield size={24} className="text-white" />
            <span className="font-bold text-xl">Access Manager</span>
          </div>
          
          <div className="flex items-center space-x-6">
            {currentUser?.role === 'Admin' && (
              <Link 
                to="/admin" 
                className="hover:text-blue-200 transition duration-200"
              >
                Admin Dashboard
              </Link>
            )}
            
            {(currentUser?.role === 'Admin' || currentUser?.role === 'Manager') && (
              <Link 
                to="/manager" 
                className="hover:text-blue-200 transition duration-200"
              >
                Manager Dashboard
              </Link>
            )}
            
            {(currentUser?.role === 'Admin' || currentUser?.role === 'Employee') && (
              <Link 
                to="/employee" 
                className="hover:text-blue-200 transition duration-200"
              >
                Employee Dashboard
              </Link>
            )}
            
            <div className="flex items-center space-x-2 ml-4 px-3 py-1 bg-blue-700 rounded-full">
              <User size={18} className="text-blue-200" />
              <span className="text-sm">{currentUser?.username}</span>
              <span className="text-xs px-2 py-0.5 bg-blue-500 rounded-full">
                {currentUser?.role}
              </span>
            </div>
            
            <button
              onClick={handleLogout}
              className="flex items-center space-x-1 hover:text-blue-200 transition duration-200"
            >
              <LogOut size={18} />
              <span>Logout</span>
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;