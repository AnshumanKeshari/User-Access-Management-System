import React from 'react';
import { Navigate } from 'react-router-dom';
import { useUser } from '../contexts/UserContext';

interface ProtectedRouteProps {
  children: React.ReactNode;
  allowedRoles: string[];
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ 
  children, 
  allowedRoles 
}) => {
  const { isAuthenticated, currentUser } = useUser();
  
  if (!isAuthenticated) {
    return <Navigate to="/login" />;
  }
  
  if (currentUser && !allowedRoles.includes(currentUser.role)) {
    // Redirect based on role if accessing unauthorized route
    if (currentUser.role === 'Employee') {
      return <Navigate to="/employee" />;
    } else if (currentUser.role === 'Manager') {
      return <Navigate to="/manager" />;
    } else if (currentUser.role === 'Admin') {
      return <Navigate to="/admin" />;
    }
  }
  
  return <>{children}</>;
};

export default ProtectedRoute;