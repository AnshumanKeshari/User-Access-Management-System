import React, { useState } from 'react';
import { useSoftware } from '../../contexts/SoftwareContext';

const CreateSoftware: React.FC = () => {
  const { addSoftware } = useSoftware();
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [accessLevels, setAccessLevels] = useState<string[]>(['Read']);
  const [message, setMessage] = useState({ type: '', text: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name || !description || accessLevels.length === 0) {
      setMessage({ 
        type: 'error', 
        text: 'Please fill in all fields and select at least one access level' 
      });
      return;
    }
    
    addSoftware(name, description, accessLevels);
    
    // Reset form
    setName('');
    setDescription('');
    setAccessLevels(['Read']);
    
    setMessage({ 
      type: 'success', 
      text: 'Software added successfully' 
    });
    
    // Clear success message after 3 seconds
    setTimeout(() => {
      setMessage({ type: '', text: '' });
    }, 3000);
  };

  const toggleAccessLevel = (level: string) => {
    if (accessLevels.includes(level)) {
      setAccessLevels(accessLevels.filter((l) => l !== level));
    } else {
      setAccessLevels([...accessLevels, level]);
    }
  };

  return (
    <div className="bg-white shadow-sm rounded-lg p-6">
      <h2 className="text-xl font-semibold text-gray-800 mb-4">
        Create New Software
      </h2>
      
      {message.text && (
        <div
          className={`p-4 mb-4 rounded-md ${
            message.type === 'success'
              ? 'bg-green-50 text-green-800 border-l-4 border-green-500'
              : 'bg-red-50 text-red-800 border-l-4 border-red-500'
          }`}
        >
          {message.text}
        </div>
      )}
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label 
            htmlFor="name" 
            className="block text-sm font-medium text-gray-700 mb-1"
          >
            Software Name
          </label>
          <input
            type="text"
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
            placeholder="Enter software name..."
          />
        </div>
        
        <div>
          <label 
            htmlFor="description" 
            className="block text-sm font-medium text-gray-700 mb-1"
          >
            Description
          </label>
          <textarea
            id="description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={4}
            className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
            placeholder="Describe the software and its purpose..."
          />
        </div>
        
        <div>
          <span className="block text-sm font-medium text-gray-700 mb-2">
            Access Levels
          </span>
          <div className="flex flex-wrap gap-4">
            {['Read', 'Write', 'Admin'].map((level) => (
              <label
                key={level}
                className="inline-flex items-center"
              >
                <input
                  type="checkbox"
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                  checked={accessLevels.includes(level)}
                  onChange={() => toggleAccessLevel(level)}
                />
                <span className="ml-2 text-sm text-gray-700">{level}</span>
              </label>
            ))}
          </div>
        </div>
        
        <div className="pt-2">
          <button
            type="submit"
            className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition duration-200"
          >
            Create Software
          </button>
        </div>
      </form>
    </div>
  );
};

export default CreateSoftware;