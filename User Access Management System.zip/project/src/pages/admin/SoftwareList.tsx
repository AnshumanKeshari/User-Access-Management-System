import React from 'react';
import { useSoftware } from '../../contexts/SoftwareContext';
import { Database, Shield } from 'lucide-react';

const SoftwareList: React.FC = () => {
  const { software } = useSoftware();

  return (
    <div className="bg-white shadow-sm rounded-lg p-6">
      <h2 className="text-xl font-semibold text-gray-800 mb-4">
        Software Applications
      </h2>
      
      {software.length === 0 ? (
        <div className="text-center p-6 bg-gray-50 rounded-md">
          <p className="text-gray-500">No software applications have been added yet.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {software.map((sw) => (
            <div
              key={sw.id}
              className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow duration-200"
            >
              <div className="p-5">
                <div className="flex items-center mb-3">
                  <Database className="h-6 w-6 text-blue-500 mr-2" />
                  <h3 className="text-lg font-semibold text-gray-900 truncate">
                    {sw.name}
                  </h3>
                </div>
                <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                  {sw.description}
                </p>
                <div className="mt-3">
                  <h4 className="text-xs font-medium text-gray-500 uppercase tracking-wider mb-1 flex items-center">
                    <Shield className="h-3.5 w-3.5 mr-1" />
                    Access Levels
                  </h4>
                  <div className="flex flex-wrap gap-1">
                    {sw.accessLevels.map((level) => (
                      <span
                        key={level}
                        className="inline-block px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800"
                      >
                        {level}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default SoftwareList;