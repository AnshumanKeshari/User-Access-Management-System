import React, { useState } from 'react';
import { useSoftware } from '../../contexts/SoftwareContext';
import { useRequest } from '../../contexts/RequestContext';
import { useUser } from '../../contexts/UserContext';

const RequestAccess: React.FC = () => {
  const { software } = useSoftware();
  const { addRequest } = useRequest();
  const { currentUser } = useUser();
  
  const [softwareId, setSoftwareId] = useState('');
  const [accessType, setAccessType] = useState('Read');
  const [reason, setReason] = useState('');
  const [message, setMessage] = useState({ type: '', text: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!softwareId || !accessType || !reason) {
      setMessage({ 
        type: 'error', 
        text: 'Please fill in all fields' 
      });
      return;
    }
    
    if (currentUser) {
      addRequest(
        currentUser.id,
        parseInt(softwareId),
        accessType,
        reason
      );
      
      // Reset form
      setSoftwareId('');
      setAccessType('Read');
      setReason('');
      
      setMessage({ 
        type: 'success', 
        text: 'Access request submitted successfully' 
      });
      
      // Clear success message after 3 seconds
      setTimeout(() => {
        setMessage({ type: '', text: '' });
      }, 3000);
    }
  };

  const selectedSoftware = software.find(
    (s) => s.id === parseInt(softwareId)
  );

  return (
    <div className="bg-white shadow-sm rounded-lg p-6">
      <h2 className="text-xl font-semibold text-gray-800 mb-4">
        Request Software Access
      </h2>
      
      {message.text && (
        <div
          className={`p-4 mb-4 rounded-md ${
            message.type === 'success'
              ? 'bg-green-50 text-green-800 border-l-4 border-green-500'
              : 'bg-red-50 text-red-800 border-l-4 border-red-500'
          }`}
        >
          {message.text}
        </div>
      )}
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label 
            htmlFor="software" 
            className="block text-sm font-medium text-gray-700 mb-1"
          >
            Software Application
          </label>
          <select
            id="software"
            value={softwareId}
            onChange={(e) => setSoftwareId(e.target.value)}
            className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
          >
            <option value="">Select software...</option>
            {software.map((sw) => (
              <option key={sw.id} value={sw.id}>
                {sw.name}
              </option>
            ))}
          </select>
        </div>
        
        {selectedSoftware && (
          <div className="bg-gray-50 p-4 rounded-md mb-4">
            <h3 className="text-sm font-medium text-gray-700 mb-1">
              Software Description
            </h3>
            <p className="text-sm text-gray-600">{selectedSoftware.description}</p>
          </div>
        )}
        
        <div>
          <label 
            htmlFor="accessType" 
            className="block text-sm font-medium text-gray-700 mb-1"
          >
            Access Type
          </label>
          <select
            id="accessType"
            value={accessType}
            onChange={(e) => setAccessType(e.target.value)}
            className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
          >
            {selectedSoftware?.accessLevels.map((level) => (
              <option key={level} value={level}>
                {level}
              </option>
            )) || (
              <>
                <option value="Read">Read</option>
                <option value="Write">Write</option>
                <option value="Admin">Admin</option>
              </>
            )}
          </select>
        </div>
        
        <div>
          <label 
            htmlFor="reason" 
            className="block text-sm font-medium text-gray-700 mb-1"
          >
            Reason for Request
          </label>
          <textarea
            id="reason"
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            rows={4}
            className="shadow-sm focus:ring-blue-500 focus:border-blue-500 mt-1 block w-full sm:text-sm border-gray-300 rounded-md"
            placeholder="Explain why you need access to this software..."
          />
        </div>
        
        <div className="pt-2">
          <button
            type="submit"
            className="w-full inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition duration-200"
          >
            Submit Request
          </button>
        </div>
      </form>
    </div>
  );
};

export default RequestAccess;