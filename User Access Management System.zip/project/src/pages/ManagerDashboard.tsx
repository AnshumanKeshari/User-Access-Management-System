import React from 'react';
import { useUser } from '../contexts/UserContext';
import { SoftwareProvider } from '../contexts/SoftwareContext';
import { RequestProvider } from '../contexts/RequestContext';
import PendingRequests from './manager/PendingRequests';

const ManagerDashboard: React.FC = () => {
  const { currentUser } = useUser();

  if (!currentUser) {
    return null;
  }

  return (
    <SoftwareProvider>
      <RequestProvider>
        <div>
          <div className="bg-white shadow-sm rounded-lg p-6 mb-6">
            <h1 className="text-2xl font-bold text-gray-800 mb-2">Manager Dashboard</h1>
            <p className="text-gray-600">
              Welcome back, <span className="font-medium">{currentUser.username}</span>. 
              Here you can review and process access requests from employees.
            </p>
          </div>
          
          <PendingRequests />
        </div>
      </RequestProvider>
    </SoftwareProvider>
  );
};

export default ManagerDashboard;