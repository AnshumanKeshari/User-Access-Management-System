import React, { useState } from 'react';
import { useRequest } from '../../contexts/RequestContext';
import { CheckCircle, XCircle, AlertTriangle, Info } from 'lucide-react';

const PendingRequests: React.FC = () => {
  const { getPendingRequests, updateRequestStatus } = useRequest();
  const [message, setMessage] = useState({ type: '', text: '' });
  const [selectedRequest, setSelectedRequest] = useState<number | null>(null);
  
  const pendingRequests = getPendingRequests();

  const handleApprove = (id: number) => {
    updateRequestStatus(id, 'Approved');
    setMessage({ 
      type: 'success', 
      text: 'Request approved successfully' 
    });
    setSelectedRequest(null);
    
    // Clear success message after 3 seconds
    setTimeout(() => {
      setMessage({ type: '', text: '' });
    }, 3000);
  };

  const handleReject = (id: number) => {
    updateRequestStatus(id, 'Rejected');
    setMessage({ 
      type: 'success', 
      text: 'Request rejected successfully' 
    });
    setSelectedRequest(null);
    
    // Clear success message after 3 seconds
    setTimeout(() => {
      setMessage({ type: '', text: '' });
    }, 3000);
  };

  return (
    <div className="bg-white shadow-sm rounded-lg p-6">
      <h2 className="text-xl font-semibold text-gray-800 mb-4">
        Pending Access Requests
      </h2>
      
      {message.text && (
        <div
          className={`p-4 mb-4 rounded-md ${
            message.type === 'success'
              ? 'bg-green-50 text-green-800 border-l-4 border-green-500'
              : 'bg-red-50 text-red-800 border-l-4 border-red-500'
          }`}
        >
          {message.text}
        </div>
      )}
      
      {pendingRequests.length === 0 ? (
        <div className="text-center p-6 bg-gray-50 rounded-md">
          <AlertTriangle className="h-12 w-12 text-yellow-500 mx-auto mb-4" />
          <p className="text-gray-700 font-medium">No pending requests</p>
          <p className="text-gray-500 mt-1">
            There are currently no access requests that need your approval.
          </p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th 
                  scope="col" 
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  Employee
                </th>
                <th 
                  scope="col" 
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  Software
                </th>
                <th 
                  scope="col" 
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  Access Type
                </th>
                <th 
                  scope="col" 
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {pendingRequests.map((request) => (
                <React.Fragment key={request.id}>
                  <tr className={`hover:bg-gray-50 transition duration-150 ${selectedRequest === request.id ? 'bg-blue-50' : ''}`}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      {request.username}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {request.softwareName}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {request.accessType}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <div className="flex space-x-2">
                        <button
                          onClick={() => setSelectedRequest(selectedRequest === request.id ? null : request.id)}
                          className="text-blue-600 hover:text-blue-900 transition duration-150 flex items-center"
                        >
                          <Info size={16} className="mr-1" />
                          Details
                        </button>
                        <button
                          onClick={() => handleApprove(request.id)}
                          className="text-green-600 hover:text-green-900 transition duration-150 flex items-center"
                        >
                          <CheckCircle size={16} className="mr-1" />
                          Approve
                        </button>
                        <button
                          onClick={() => handleReject(request.id)}
                          className="text-red-600 hover:text-red-900 transition duration-150 flex items-center"
                        >
                          <XCircle size={16} className="mr-1" />
                          Reject
                        </button>
                      </div>
                    </td>
                  </tr>
                  {selectedRequest === request.id && (
                    <tr className="bg-blue-50">
                      <td colSpan={4} className="px-6 py-4">
                        <div className="border-l-4 border-blue-500 pl-4">
                          <h4 className="text-sm font-medium text-gray-900 mb-1">
                            Reason for Request:
                          </h4>
                          <p className="text-sm text-gray-600 mb-3">{request.reason}</p>
                          <div className="flex space-x-3 mt-2">
                            <button
                              onClick={() => handleApprove(request.id)}
                              className="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded-full shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 transition duration-150"
                            >
                              <CheckCircle size={14} className="mr-1" />
                              Approve
                            </button>
                            <button
                              onClick={() => handleReject(request.id)}
                              className="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded-full shadow-sm text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 transition duration-150"
                            >
                              <XCircle size={14} className="mr-1" />
                              Reject
                            </button>
                          </div>
                        </div>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default PendingRequests;