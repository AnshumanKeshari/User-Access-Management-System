import React, { useState } from 'react';
import { Route, Routes } from 'react-router-dom';
import { useUser } from '../contexts/UserContext';
import { useSoftware } from '../contexts/SoftwareContext';
import { useRequest } from '../contexts/RequestContext';
import RequestAccess from './employee/RequestAccess';
import MyRequests from './employee/MyRequests';
import { SoftwareProvider } from '../contexts/SoftwareContext';
import { RequestProvider } from '../contexts/RequestContext';
import { Layers, List, PlusCircle } from 'lucide-react';

const EmployeeDashboard: React.FC = () => {
  const { currentUser } = useUser();
  const [activeTab, setActiveTab] = useState('request');

  if (!currentUser) {
    return null;
  }

  return (
    <SoftwareProvider>
      <RequestProvider>
        <div>
          <div className="bg-white shadow-sm rounded-lg p-6 mb-6">
            <h1 className="text-2xl font-bold text-gray-800 mb-2">Employee Dashboard</h1>
            <p className="text-gray-600">
              Welcome back, <span className="font-medium">{currentUser.username}</span>. 
              Here you can request access to software and view your existing requests.
            </p>
          </div>
          
          <div className="flex mb-6">
            <button
              onClick={() => setActiveTab('request')}
              className={`flex items-center px-4 py-2 mr-2 rounded-md ${
                activeTab === 'request'
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-100'
              } transition duration-200`}
            >
              <PlusCircle size={18} className="mr-2" />
              Request Access
            </button>
            <button
              onClick={() => setActiveTab('my-requests')}
              className={`flex items-center px-4 py-2 rounded-md ${
                activeTab === 'my-requests'
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-100'
              } transition duration-200`}
            >
              <List size={18} className="mr-2" />
              My Requests
            </button>
          </div>
          
          {activeTab === 'request' ? (
            <RequestAccess />
          ) : (
            <MyRequests />
          )}
        </div>
      </RequestProvider>
    </SoftwareProvider>
  );
};

export default EmployeeDashboard;