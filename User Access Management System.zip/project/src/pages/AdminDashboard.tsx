import React, { useState } from 'react';
import { useUser } from '../contexts/UserContext';
import { SoftwareProvider } from '../contexts/SoftwareContext';
import { RequestProvider } from '../contexts/RequestContext';
import CreateSoftware from './admin/CreateSoftware';
import SoftwareList from './admin/SoftwareList';
import { Layers, List } from 'lucide-react';

const AdminDashboard: React.FC = () => {
  const { currentUser } = useUser();
  const [activeTab, setActiveTab] = useState('create');

  if (!currentUser) {
    return null;
  }

  return (
    <SoftwareProvider>
      <RequestProvider>
        <div>
          <div className="bg-white shadow-sm rounded-lg p-6 mb-6">
            <h1 className="text-2xl font-bold text-gray-800 mb-2">Admin Dashboard</h1>
            <p className="text-gray-600">
              Welcome back, <span className="font-medium">{currentUser.username}</span>. 
              Here you can manage software applications and their access controls.
            </p>
          </div>
          
          <div className="flex mb-6">
            <button
              onClick={() => setActiveTab('create')}
              className={`flex items-center px-4 py-2 mr-2 rounded-md ${
                activeTab === 'create'
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-100'
              } transition duration-200`}
            >
              <Layers size={18} className="mr-2" />
              Create Software
            </button>
            <button
              onClick={() => setActiveTab('list')}
              className={`flex items-center px-4 py-2 rounded-md ${
                activeTab === 'list'
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-100'
              } transition duration-200`}
            >
              <List size={18} className="mr-2" />
              Software List
            </button>
          </div>
          
          {activeTab === 'create' ? (
            <CreateSoftware />
          ) : (
            <SoftwareList />
          )}
        </div>
      </RequestProvider>
    </SoftwareProvider>
  );
};

export default AdminDashboard;